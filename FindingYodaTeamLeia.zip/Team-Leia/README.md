# Baby-Yoda-Team-Leia
We are powerful members of Team Leia that is searching for Baby Yoda on the Galaxy and protect our master. Our collaborator team includes Nurlan_Sarkhanov, Udawala_Hewage_Dil, Joshua Batt, and Thanh Nguyen. Here below is our tasks and challenges that need to be achieved within a day:
We think there are 3 different galaxies in our cluster of data find them
and map them.
2. Generate a map only of the uppermost galaxy
3. we think BeBe Yoda is in the rightmost planet of this galaxy.Plot the
highlighted planet on the original data
4. input the coordinates into the force finder
5. From the planet data you will need to extract the force concentration
and its two principal components. Map them.
6. Find BeBe Yoda in the closest point to the gravitational center of the
two principal components of the force. Highlight in a map the
gravitational center and the closest point.
7. Deliver the force coordinates to high command. 
Thank you!
